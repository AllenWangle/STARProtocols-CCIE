import json
import xml.dom.minidom as md
import os

def readXML(path):

    dom= md.parse(path)

    facts=dom.documentElement
    train_dicts=[]
    sentId=0
    for fact in facts.childNodes:
        if(fact.nodeName=='fact'):
            for child in fact.childNodes:
                entitymentions=[]
                if child.nodeName=="content":
                    content=child
                    for con in content.childNodes:
                        text=con.nodeValue
                if child.nodeName=="entitys":
                    entitys=child
                    entitydict={}
                    for entity in entitys.childNodes:
                        if entity.nodeName=="entity":
                            entitymention={}
                            start=int(entity.getAttribute("position").split("-")[0])
                            end=int(entity.getAttribute("position").split("-")[1])
                            label=entity.getAttribute("type")
                            entityid=entity.getAttribute("id")
                            for e in entity.childNodes:
                                entitytext=e.nodeValue
                            entitydict[entityid]=(entitytext,start)
                            entitymention["start"]=start
                            entitymention["end"]=end
                            entitymention["label"]=label
                            entitymention["text"]=entitytext
                            entitymentions.append(entitymention)
                    
                    if len(text.split())==0:
                        continue
                    train_dict={}
                    train_dict["sentText"]=text
                    train_dict["entityMentions"]=entitymentions
                    train_dict['ID']=text.strip().split('##')[0]
                    train_dicts.append(train_dict)
                
    return train_dicts

def writedata(path,dic):
    fout1 = open(path,'w',encoding='utf-8')
    for d in dic:
        sentence_text=list(d["sentText"].strip().strip('"'))
        label=['O' for i in range(len(sentence_text))]
        for e in d['entityMentions']:
            label[e['start']]='B-'+e['label']
            for i in range(e['start']+1,e['end']):
                label[i]='I-'+e['label']
        idlength=len(d['ID'])
        for j in range(idlength+2,len(label)):
            fout1.write(sentence_text[j]+'\t'+label[j]+'\n')
        fout1.write('\n')
    fout1.close()

if __name__ == "__main__":
    path='xml'
    pathDir=os.listdir(path)
    trDict=[]
    devDict=[]
    teDict=[]
    for artid,p in enumerate(pathDir):
        if p.startswith('dev'):
            file = os.path.join('%s/%s' % (path, p))  # os.path.join()：  将多个路径组合后返回
            print('dev',file)
            deDicts=readXML(file)
            devDict.extend(deDicts)
        if p.startswith('train'):
            file = os.path.join('%s/%s' % (path, p))  # os.path.join()：  将多个路径组合后返回
            print('train',file)
            trainDicts=readXML(file)
            trDict.extend(trainDicts)
        
        if p.startswith('test'):
            file = os.path.join('%s/%s' % (path, p))  # os.path.join()：  将多个路径组合后返回
            print('test',file)
            teDicts=readXML(file)
            teDict.extend(teDicts)
            
    writedata(path+'/dev_lto.txt',devDict)
    writedata(path+'/train_lto.txt',trDict)
    writedata(path+'/test_lto.txt',teDict)
