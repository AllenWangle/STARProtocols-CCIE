import pandas as pd
import numpy as np
import jieba

def df_to_list(DF, field):
    temp_data = []
    for index, row in DF.iterrows():
        temp_data.append([row["Original_Text_CN"],row[field]])
    return temp_data

def word_cut(text):
    w = []
    for i in jieba.cut(text,cut_all=False):
        w.append(i)
    return w

if __name__ == "__main__":

    key_vocab = {
            "Event":
                {"Event_unknown": {"NA","nan"},
                "Event_travel":{"出行","交通工具","途经","路经"},
                "Event_tourism":{"旅行","旅居","旅游"},
                "Event_work":{"工作","出差","务工","开会","上学","经商","进货"},
                "Event_hospital":{"医院","医","病"},
                "Event_residence":{"居住","常住","生活"},
                "Event_party":{"聚会","聚餐","接","接触","探亲","婚","培训","打牌","家庭","购物","超市","暴露"},
                "Event_return":{"返乡","返回"}},
            "Place":
                    {"Place_unkown": {"NA","nan"},
                    "Place_public": {"餐厅", "公共场所", "公共交通", "商场", "室外","医院"},
                    "Place_social": {"家庭", "社交场所", "室内", "学校", "工作场所"}},
            "Person":
                    {"Person_unkown": {"NA","nan"},
                    "Person_other": {"家人", "朋友", "同事", "同学", "境外","外地","成都","同乘"},
                    "Place_epidemic": {"武汉", "湖北", "宜昌"},
                    "Place_confirm": {"确诊", "疑似", "病例"}},        
            "Discover":
                    {"Discover_unkown": {"NA","nan"},
                    "Discover_passive": {"被动排查"},
                    "Discover_isolated": {"隔离发现"},
                    "Discover_self": {"主动就诊"}},
            "Isolate":
                    {"Isolate_unkown": {"NA","nan"},
                    "Isolate_center": {"集中隔离"},
                    "Isolate_home": {"居家隔离"},
                    "Isolate_institution": {"医疗机构"}},        
            "Degree":
                    {"Degree_unkown": {"NA","nan"},
                    "Degree_light": {"轻度"},
                    "Degree_stable": {"稳定"},
                    "Degree_above": {"中度","重度"}}
            }

    cate2key = {"Place_and_Event":"Event","Venue":"Place","With_Whom":"Person","Method_Discovery":"Discover","Place_Quarantine":"Isolate","Symptom_Severity":"Degree"}
    value2id = {
        "Event":
                {"Event_unknown": 0,
                "Event_travel":1,
                "Event_tourism":2,
                "Event_work":3,
                "Event_hospital":4,
                "Event_residence":5,
                "Event_party":6,
                "Event_return":7},
            "Place":
                    {"Place_unkown": 0,
                    "Place_public": 1,
                    "Place_social": 2},
            "Person":
                    {"Person_unkown": 0,
                    "Person_other": 1,
                    "Place_epidemic": 2,
                    "Place_confirm": 3},        
            "Discover":
                    {"Discover_unkown": 0,
                    "Discover_passive": 1,
                    "Discover_isolated": 2,
                    "Discover_self": 3},
            "Isolate":
                    {"Isolate_unkown": 0,
                    "Isolate_center": 1,
                    "Isolate_home": 2,
                    "Isolate_institution": 3},        
            "Degree":
                    {"Degree_unkown": 0,
                    "Degree_light": 1,
                    "Degree_stable": 2,
                    "Degree_above": 3}
    }


    raw_data = pd.read_excel("dataset_CN.xls",header=0)
    raw_data["Original_Text_CN"] = raw_data["Original_Text_CN"].str.replace("\n", "").replace(" ","").replace("\t","").replace("r","")
    category = ["Place_and_Event", "Venue", "With_Whom", "Method_Discovery", "Place_Quarantine", "Symptom_Severity"]

    for term in category:
        label, label_num = [], []
        key = str(cate2key[term])
        data = df_to_list(raw_data, str(term))
        for line in data:
            sign = False
            br = False
            word = word_cut(str(line[1]))
            for k, value in key_vocab[key].items():
                
                for v in value:
                    if v in word:
                        label.append(k)
                        label_num.append(value2id[key][k])
                        sign = True
                        br = True
                        break
                if br:
                    break
            if sign == False:
                    label.append("Please manually annotate it")
                    label_num.append("Please manually annotate it")     
                
        raw_data.insert(loc=len(raw_data.columns),column=key+"_label",value=label)
        raw_data.insert(loc=len(raw_data.columns),column=key+"_num_label",value=label_num)
        
        cls_data = raw_data[["Original_Text_CN", term, key+"_label", key+"_num_label"]]
        cls_data.to_csv(key.lower()+".csv", index=None) 