import pandas as pd
import numpy as np
import datetime
from sklearn.model_selection import train_test_split

if __name__ == "__main__":
    
    ## split raw data into train.txt, dev.txt, and test.txt with a ratio of 8:1:1.
    raw_data = pd.read_excel("dataset_CN.xls",header=0)
    raw_data["Original_Text_CN"] = raw_data["Original_Text_CN"].str.replace("\n", "").replace(" ","").replace("\t","").replace("r","")
    new_data = raw_data[["ID","Original_Text_CN"]]
    train, test = train_test_split(new_data, train_size=0.9)
    train, dev = train_test_split(train, train_size=0.9)
    train.to_csv("train.txt", sep="#", index=None, header=None)
    dev.to_csv("dev.txt", sep="#", index=None, header=None)
    test.to_csv("test.txt", sep="#", index=None, header=None)
    
    ## reorganize the data into three-cloumn fromat.
    list = ["cut_list","ner_list","pos_list"]
    for term in ["train", "dev", "test"]:
        with open(term+".txt") as file:
            word_list = []
            for line in file.readlines():
                word_list.append(list)
                arr = line.strip().split("#")
                word_list.append([arr[0], "O", "O"])
                word_list.append(["#", "O", "O"])
                for token in arr[1]:
                    word_list.append([token, "O", "O"])
                # annotation_list.append(word_list)
        np.savetxt("CCIE/annotation/data"+ term +"_annotation.txt",np.asarray(word_list),fmt="%s", delimiter=",", newline="\n")