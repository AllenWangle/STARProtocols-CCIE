#!/bin/bash
GPUID=0
TRAINRATIO=0.3
SAVETAG="Roberta_wwm"_$TRAINRATIO
CKPTTYPE="base_model_bert"
USE_ELECTRA="false"

echo $SAVETAG
for dataset in 'thick' 'thin' 'drug' 'baseinf2' 'baseinf3'
do
    if [ $dataset == "thick" ]
    then
        type="thick"
    elif [ $dataset == "thin" ]
    then
        type="thin"
    else
        type="drug"
    fi 
    python train_base_model_bert.py --gpu_idx $GPUID --language $dataset --data_type $type --epochs 40 --train_ratio $TRAINRATIO --save_tag $SAVETAG --ckpt_save_type $CKPTTYPE --batch_size 16 --bert_model_path premodel/chinese_roberta_wwm_ext_L-12_H-768_A-12 --use_electra $USE_ELECTRA
done