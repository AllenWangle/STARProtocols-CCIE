import pandas as pd

def prepro():
    data = pd.read_excel('新病例.xlsx')
    contents=list(data['文本里关于病例的描述性信息'])
    print(len(contents))
    with open("datasets/raw/wzz/0222/1/test.txt","w",encoding='utf-8') as f:
        for content in contents:
            if isinstance(content,str):
                content=content.replace('\n','')
                for char in content:
                    f.write(char+'\t'+'O'+'\n')       
            else:
                print("病例文本输入不正确！")
                f.write('。'+'\n')
            f.write('\n')