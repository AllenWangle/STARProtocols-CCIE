# %%
class Configurations:
    def __init__(self):
        # set common arguments
        self.iobes= False
        self.rew_path ="datasets/raw/MSRA"
        self.char_lowercase= True
        self.word_lowercase= False
        self.data_type = 'drug'
        self.train_file = os.path.join(self.rew_path,'train.txt')
        self.dev_file = os.path.join(self.rew_path,'valid.txt')
        self.test_file = os.path.join(self.rew_path,'test.txt')
config = Configurations()


# %%
from utils.prepro_data_lner import load_dataset
from collections import Counter

def build_token_counters_split(datasets):
    word_counter = Counter()
    label_counter = Counter()
    label_list = []
    for dataset in datasets:
        for record in dataset:
            for word in record["words"]:
                word_counter[word] += 1

            for label in record["labels"]:
                label_counter[label] += 1
        label_list.append(label_counter)
    return word_counter,  label_counter, label_list

def return_label(dataset):
    label_counter = Counter()
    for record in dataset:
        for label in record["labels"]:
            label_counter[label] += 1
    return label_counter


def read_data_and_vocab_for_contunt(train_file, dev_file, test_file, data_type, config):
    train_data = load_dataset(train_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                              char_lowercase=config.char_lowercase)
    dev_data = load_dataset(dev_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                            char_lowercase=config.char_lowercase)
    test_data = load_dataset(test_file, iobes=config.iobes, data_type=data_type, lowercase=config.word_lowercase,
                             char_lowercase=config.char_lowercase)
    train_label = return_label(train_data)
    dev_label = return_label(dev_data)
    test_label = return_label(test_data)
    word_counter,  label_counter, label_list = build_token_counters_split([train_data, dev_data, test_data])
    return train_data, dev_data, test_data, word_counter, label_counter, [train_label,dev_label,test_label]
# %%
import os
rew_path = "datasets/raw/drug"
train_file = os.path.join(rew_path,'train.txt')
train_file = os.path.join(rew_path,'valid.txt')
train_file = os.path.join(rew_path,'test.txt')
data_type = 'drug'
# from utils.prepro_data_lner import read_data_and_vocab

train_data, dev_data, test_data, word_counter, label_counter, label_list = read_data_and_vocab_for_contunt(
        config.train_file, config.dev_file, config.test_file, data_type=config.data_type, config=config)
    # create save path

# %%
label_list

# %%
def returnSum(myDict):       
    sum = 0
    for i in myDict: 
        sum = sum + myDict[i]       
    return sum
def return_entiy(laber_dict):
    entiy_dict = {}
    for i in laber_dict.keys():
        if 'B-' in i:
            entiy_dict[i[2:]] = laber_dict[i]
    return entiy_dict

def merge_dict(x,y):
    for k,v in x.items():
                if k in y.keys():
                    y[k] += v
                else:
                    y[k] = v
def return_all_sum(train_data,dev_data,test_data):
    data_list = [train_data,dev_data,test_data]
    token_sum_list = []
    sentice_sum = 0    
    for date_set in data_list:
        # token_sum += returnSum(date_set)
        sentice_sum += len(date_set)
        token_sum_list.append(len(date_set))
    return token_sum_list
token_list = []
entity_sum_list = []
for label in label_list:
    token = returnSum(label)
    entiy_dict = return_entiy(label)
    entiy_sum = returnSum(entiy_dict)
    token_list.append(token)
    entity_sum_list.append(entiy_sum)
    print(entiy_dict)
sentice_sum = return_all_sum(train_data,dev_data,test_data)
entiy_dict_sum = return_entiy(label_counter)
print(sentice_sum,token_list,entity_sum_list,'\n',entiy_dict_sum)

# %%
rew_dict = {}

def merge_dict(x,y):
    for k,v in x.items():
                if k in y.keys():
                    y[k] += v
                else:
                    y[k] = v
merge_dict(entiy_dict,rew_dict)    
print(rew_dict)          
# %%

import models.ON_LSTm as rnn

# %%
class Bi_On_LSTM:
    def __init__(self, num_units, drop_rate=0.0, activation=tf.tanh, concat=True, reuse=None, scope="bi_rnn"):
        self.reuse, self.scope, self.concat = reuse, scope, concat
        with tf.variable_scope(self.scope, reuse=self.reuse):            
            self.cell_fw =rnn.ON_LSTM(
                        num_units,
                        chunk_size = 10,
                        use_peepholes=True,
                        initializer=self.initializer,
                        state_is_tuple=True)
            self.cell_bw = rnn.ON_LSTM(
                        num_units,
                        chunk_size = 10,
                        use_peepholes=True,
                        initializer=self.initializer,
                        state_is_tuple=True)
            self.rnn_dropout = tf.layers.Dropout(rate=drop_rate)
            if not self.concat:
                self.dense_fw = tf.layers.Dense(units=num_units, use_bias=False, _reuse=self.reuse, name="dense_fw")
                self.dense_bw = tf.layers.Dense(units=num_units, use_bias=False, _reuse=self.reuse, name="dense_bw")
                self.bias = tf.get_variable(name="bias", shape=[num_units], dtype=tf.float32, trainable=True)
                self.activation = activation

    def __call__(self, inputs, seq_len, training):
        with tf.variable_scope(self.scope, reuse=self.reuse):
            outputs, _ = tf.nn.bidirectional_dynamic_rnn(self.cell_fw, self.cell_bw, inputs, seq_len, dtype=tf.float32)
            if self.concat:
                outputs = tf.concat(outputs, axis=-1)
                outputs = self.rnn_dropout(outputs, training=training)
            else:
                output1 = self.rnn_dropout(outputs[0], training=training)
                output2 = self.rnn_dropout(outputs[1], training=training)
                outputs = self.dense_fw(output1) + self.dense_bw(output2)
                outputs = self.activation(tf.nn.bias_add(outputs, bias=self.bias))
            return outputs
