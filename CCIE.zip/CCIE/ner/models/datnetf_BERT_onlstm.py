import tensorflow as tf
import numpy as np
from models.shares import Base, flip_gradient, CharTDNNHW, BiRNN, CRF, self_attn, focal_loss, Embedding,save_cr_and_cm,print_config,Bi_On_LSTM
from utils.logger import Progbar
import os
import time
from utils.progressbar import ProgressBar
from utils.bert import modeling
from bert.modeling import BertConfig, BertModel
import tokenization
class DATNetFModel(Base):
    """Full Transfer and DATNet-F modules"""
    def __init__(self, config):
        super(DATNetFModel, self).__init__(config)
        self._init_configs()
        with tf.Graph().as_default():
            self._add_placeholders()
            self._build_model()
            self.logger.info("total params: {}".format(self.count_params("computation_graph")))
            with open(os.path.join(self.cfg.checkpoint_path,'speed.txt'),"a+",encoding='utf-8') as inp:
                inp.write("total params: {}/n".format(self.count_params("computation_graph")))
            print_config(config,self.logger,Base=False)
            self._initialize_session()
            # self._restore_bert()
            self._tensorboard()

    def _init_configs(self):
        # s_vocab = self.load_dataset(self.cfg.src_vocab)
        # t_vocab = self.load_dataset(self.cfg.tgt_vocab)
        # self.sw_dict, self.sl_dict = s_vocab["word_dict"], s_vocab["label_dict"]
        # self.tw_dict, self.tl_dict = t_vocab["word_dict"], t_vocab["label_dict"]
        # del s_vocab, t_vocab
        # self.sw_size,  self.sl_size = len(self.sw_dict),  len(self.sl_dict)
        # self.tw_size,  self.tl_size = len(self.tw_dict),  len(self.tl_dict)
        # self.rev_sw_dict = dict([(idx, word) for word, idx in self.sw_dict.items()])       
        # self.rev_sl_dict = dict([(idx, label) for label, idx in self.sl_dict.items()])
        # self.rev_tw_dict = dict([(idx, word) for word, idx in self.tw_dict.items()])       
        # self.rev_tl_dict = dict([(idx, label) for label, idx in self.tl_dict.items()])
        # self.bert_config = BertConfig(21128) # TODO
        tokenization.validate_case_matches_checkpoint(self.cfg.word_lowercase,
                                                  self.cfg.bert_model_path)
        self.tokenizer = tokenization.FullTokenizer(
                vocab_file=self.cfg.vocab_file, do_lower_case=self.cfg.word_lowercase)
        
        self.bert_config = BertConfig.from_json_file(self.cfg.bert_config) # 配置文件地址。
        self.sl_size = len(self.cfg.src_label2id)
        self.tl_size = len(self.cfg.tgt_label2id)
        self.rev_sw_dict = self.tokenizer.inv_vocab
        self.rev_tw_dict = self.tokenizer.inv_vocab
        self.rev_sl_dict = dict([(idx, label) for label, idx in self.cfg.src_label2id.items()])
        self.rev_tl_dict = dict([(idx, label) for label, idx in self.cfg.tgt_label2id.items()])

    def _init_bert_model(self,config):
        # bert模型参数初始化的地方
        init_checkpoint = self.cfg.init_checkpoint
        # 获取模型中所有的训练参数。
        tvars = tf.trainable_variables()
        # 加载BERT模型
        (assignment_map, initialized_variable_names) = modeling.get_assignment_map_from_checkpoint(tvars,
                                                                                                   init_checkpoint)
        tf.train.init_from_checkpoint(init_checkpoint, assignment_map)
        
        self.tokenizer = tokenization.FullTokenizer(vocab_file=os.path.join(config.bert_model_path,'vocab.txt'),
                                       do_lower_case=True)
        
        print("**** Trainable Variables ****")
        # 打印加载模型的参数
        
        if not config['para_frozen']:
            train_vars = []
            for var in tvars:
                init_string = ""
                if var.name in initialized_variable_names:
                    init_string = ", *INIT_FROM_CKPT*"
                else:
                    train_vars.append(var)
                print("  name = %s, shape = %s%s", var.name, var.shape,init_string)
        else:
            train_vars = tvars        


    def _get_feed_dict(self, src_data, tgt_data, domain_labels, is_train=False, src_lr=None, tgt_lr=None):
        feed_dict = {self.is_train: is_train}
        if src_lr is not None:
            feed_dict[self.src_lr] = src_lr
        if tgt_lr is not None:
            feed_dict[self.tgt_lr] = tgt_lr
        if src_data is not None:
            feed_dict[self.input_ids] = src_data["input_ids"]
            feed_dict[self.lengths] = src_data["seq_lengths"]
            feed_dict[self.input_mask] = src_data["input_mask"]
            feed_dict[self.segment_ids] = src_data["segment_ids"]
            if "label_id" in src_data:
                feed_dict[self.labels] = src_data["label_id"]
        if tgt_data is not None:
            feed_dict[self.input_ids] = tgt_data["input_ids"]
            feed_dict[self.lengths] = tgt_data["seq_lengths"]
            feed_dict[self.input_mask] = tgt_data["input_mask"]
            feed_dict[self.segment_ids] = tgt_data["segment_ids"]
            if "label_id" in tgt_data:
                feed_dict[self.labels] = tgt_data["label_id"]
        if domain_labels is not None:
            feed_dict[self.domain_labels] = domain_labels
        return feed_dict

    def _add_placeholders(self):
        # add placeholders for the model 
        self.input_ids = tf.placeholder(dtype=tf.int32, shape=[None, None], name="src_input_ids")
        self.input_mask = tf.placeholder(dtype=tf.int32, shape=[None, None], name="src_input_mask")
        self.segment_ids = tf.placeholder(dtype=tf.int32, shape=[None, None], name="src_segment_ids")
        self.labels = tf.placeholder(tf.int32, shape=[None, None], name="src_labels") #任务1的label
        # target placeholders
        # self.tgt_input_ids = tf.placeholder(dtype=tf.int32, shape=[None, None], name="tgt_input_ids")
        # self.tgt_input_mask = tf.placeholder(dtype=tf.int32, shape=[None, None], name="tgt_input_mask")
        # self.tgt_segment_ids = tf.placeholder(dtype=tf.int32, shape=[None, None], name="tgt_segment_ids")
        # self.tgt_labels = tf.placeholder(tf.int32, shape=[None, None], name="tgt_labels")  #任务2的label

        # domain labels
        self.domain_labels = tf.placeholder(tf.int32, shape=[None, 2], name="domain_labels")        
        # hyper-parameters        
        self.is_train = tf.placeholder(tf.bool, shape=[], name="is_train")
        self.test_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.dev_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.tgt_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.src_f1 = tf.Variable(0.0,dtype=tf.float32, trainable=False)
        self.src_lr = tf.placeholder(tf.float32, name="source_learning_rate")
        self.tgt_lr = tf.placeholder(tf.float32, name="target_learning_rate")
        self.loss_summary = tf.Variable(0.0, dtype=tf.float32,trainable=False)
        self.mean_loss_summary = tf.Variable(0.0,dtype=tf.float32, trainable=False)


        self.keep_prob = tf.placeholder(tf.float32, name='keep_prob')  # , name='is_training'
        # self.num_labels = self.cfg.num_labels

        used = tf.sign(tf.abs(self.input_ids))
        length = tf.reduce_sum(used, reduction_indices=1)
        # tgt_used = tf.sign(tf.abs(self.input_ids))
        # tgt_length = tf.reduce_sum(tgt_used, reduction_indices=1)
        self.lengths = tf.cast(length, tf.int32)
        # self.tgt_lengths = tf.cast(tgt_length, tf.int32)
        self.batch_size = tf.shape(self.input_ids)[0]
        self.num_steps = tf.shape(self.input_ids)[-1]
        # self.tgt_batch_size = tf.shape(self.tgt_input_ids)[0]
        # self.tgt_num_steps = tf.shape(self.tgt_input_ids)[-1]


    def bert_embedding(self,input_ids,input_mask,segment_ids):
        # load bert embedding
        
        model = modeling.BertModel(
                config=self.bert_config,
                is_training=False,
                input_ids=input_ids,
                input_mask=input_mask,
                token_type_ids=segment_ids,
                use_one_hot_embeddings=False,
                )
        self.embedding = model.get_sequence_output()
        self.embedding_summary_op = tf.summary.histogram('bert_embedding/embedding',self.embedding)
        return self.embedding


    def _tensorboard(self):        
        tf.summary.scalar('loss/src_dis_loss', self.src_dis_loss)
        tf.summary.scalar('loss/tgt_dis_loss', self.tgt_dis_loss)       
        tf.summary.scalar('loss/src_loss', self.src_loss)  # negative critic loss
        tf.summary.scalar('loss/tgt_loss', self.tgt_loss)
        if self.cfg.at:
            tf.summary.scalar('loss/adv_tgt_loss', self.adv_tgt_loss)
            tf.summary.scalar('loss/adv_src_loss', self.adv_src_loss)
        self.summary_op = tf.summary.merge_all()
        self.tgt_F1_scalar = tf.summary.scalar('dev_F1/tgt_f1', self.tgt_f1)
        self.src_F1_scalar = tf.summary.scalar('dev_F1/src_f1', self.src_f1)
        self.F1_summary_op = tf.summary.merge([self.tgt_F1_scalar,self.src_F1_scalar])
        self.train_writer = tf.summary.FileWriter(self.cfg.summary_path + "train", self.sess.graph)
       
    def _restore_bert(self):
        tvars = tf.trainable_variables()
        initialized_variable_names = {}
        scaffold_fn = None
        init_checkpoint = os.path.join(self.cfg.bert_model_path,"bert_model.ckpt")
        if init_checkpoint:
            (assignment_map, initialized_variable_names
             ) = modeling.get_assignment_map_from_checkpoint(tvars, init_checkpoint)
 
            tf.train.init_from_checkpoint(init_checkpoint, assignment_map)

        tf.logging.info("**** Trainable Variables ****")
        for var in tvars:
            init_string = ""
            if var.name in initialized_variable_names:
                init_string = ", *INIT_FROM_CKPT*"
            tf.logging.info("  name = %s, shape = %s%s", var.name, var.shape,
                            init_string)

    def _build_model(self):
       
        # with tf.variable_scope("embeddings_op"):
            # word table

        word_emb = self.bert_embedding(self.input_ids,self.input_mask,self.segment_ids)
        # tgt_word_emb = self.bert_embedding(self.tgt_input_ids,self.tgt_input_mask,self.tgt_segment_ids)
        
            # char table (default char is shared)

        with tf.variable_scope("computation_graph"):
            # build module
            emb_dropout = tf.layers.Dropout(rate=self.cfg.emb_drop_rate)
            bi_rnn = Bi_On_LSTM(self.cfg.num_units, drop_rate=self.cfg.rnn_drop_rate, concat=self.cfg.concat_rnn,
                           activation=tf.tanh, reuse=tf.AUTO_REUSE, scope="bi_rnn")
            
            # create dense layer
            if self.cfg.share_dense:
                src_dense = tf.layers.Dense(self.sl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
                tgt_dense = tf.layers.Dense(self.tl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="project")
            else:
                src_dense = tf.layers.Dense(self.sl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="src_project")
                tgt_dense = tf.layers.Dense(self.tl_size, use_bias=True, _reuse=tf.AUTO_REUSE, name="tgt_project")
            # create CRF layer
            if self.cfg.share_label:
                src_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="crf_layer")
                tgt_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="crf_layer")
            else:
                src_crf_layer = CRF(self.sl_size, reuse=tf.AUTO_REUSE, scope="src_crf_layer")
                tgt_crf_layer = CRF(self.tl_size, reuse=tf.AUTO_REUSE, scope="tgt_crf_layer")

            # compute outputs
            def discriminator(feature):
                feat = flip_gradient(feature, lw=self.cfg.grad_rev_rate)
                outputs = self_attn(feat, reuse=tf.AUTO_REUSE, name="self_attention")
                logits = tf.layers.dense(outputs, units=2, use_bias=True, name="disc_project", reuse=tf.AUTO_REUSE)
                if self.cfg.discriminator == 2:  # GRAD
                    loss = focal_loss(logits, self.domain_labels, alpha=self.cfg.alpha, gamma=self.cfg.gamma)
                    loss = tf.reduce_mean(loss)
                else:  # normal discriminator
                    loss = tf.nn.softmax_cross_entropy_with_logits_v2(logits=logits, labels=self.domain_labels)
                    loss = tf.reduce_mean(loss)
                return loss, logits

            def compute_src_logits(word_emb):
                emb = emb_dropout(word_emb, training=self.is_train)
                rnn_outs = bi_rnn(emb, self.lengths, training=self.is_train)
                logits = src_dense(rnn_outs)
                transition, mean_loss = src_crf_layer(logits, self.labels, self.lengths)
                return rnn_outs, logits, transition, mean_loss

            def compute_tgt_logits(word_emb):
                emb = emb_dropout( word_emb, training=self.is_train)
                rnn_outs = bi_rnn(emb, self.lengths, training=self.is_train)
                logits = tgt_dense(rnn_outs)
                transition, mean_loss = tgt_crf_layer(logits, self.labels, self.lengths)
                return rnn_outs, logits, transition, mean_loss

            # train source
            src_rnn_outs, self.src_logits, self.src_transition, self.src_loss = compute_src_logits(word_emb)
            self.src_rnn_outs = tf.summary.histogram('computation_graph/src_rnn_outs', src_rnn_outs)
            if self.cfg.at:  # adversarial training
                perturb_src_word_emb = self.add_perturbation(word_emb, self.src_loss, epsilon=self.cfg.epsilon)
                *_, self.adv_src_loss = compute_src_logits(perturb_src_word_emb)
                self.src_loss = self.src_loss + self.adv_src_loss
            if self.cfg.discriminator != 0:  # if 0 means no discriminator is applied
                self.src_dis_loss, src_dis_logits = discriminator(src_rnn_outs)
                self.src_dis_logits = tf.summary.histogram('computation_graph/src_dis_logits', src_dis_logits)
                self.src_loss = self.src_loss + self.src_dis_loss

            # train target
            tgt_rnn_outs, self.tgt_logits, self.tgt_transition, self.tgt_loss = compute_tgt_logits(
                word_emb)
            self.tgt_rnn_outs = tf.summary.histogram('computation_graph/tgt_rnn_outs', tgt_rnn_outs)
            if self.cfg.at:
                perturb_tgt_word_emb = self.add_perturbation(word_emb, self.tgt_loss, epsilon=self.cfg.epsilon)
                *_, self.adv_tgt_loss = compute_tgt_logits(perturb_tgt_word_emb)
                self.tgt_loss = self.tgt_loss + self.adv_tgt_loss
            if self.cfg.discriminator != 0:
                self.tgt_dis_loss, tgt_dis_logits = discriminator(tgt_rnn_outs)
                self.tgt_dis_logits = tf.summary.histogram('computation_graph/tgt_dis_logits', tgt_dis_logits)
                self.tgt_loss = self.tgt_loss + self.tgt_dis_loss

        tvars = tf.trainable_variables()
        initialized_variable_names = {}
        scaffold_fn = None
        init_checkpoint = os.path.join(self.cfg.bert_model_path,"bert_model.ckpt")
        if init_checkpoint:
            (assignment_map, initialized_variable_names
             ) = modeling.get_assignment_map_from_checkpoint(tvars, init_checkpoint)
 
            tf.train.init_from_checkpoint(init_checkpoint, assignment_map)

        tf.logging.info("**** Trainable Variables ****")
        non_bert_vars = []
        for var in tvars:
            init_string = ""
            if var.name in initialized_variable_names:
                init_string = ", *INIT_FROM_CKPT*"
                tf.logging.info("  name = %s, shape = %s%s", var.name, var.shape,
                            init_string)
            else:
                non_bert_vars.append(var)


        src_optimizer = tf.train.AdamOptimizer(learning_rate=self.src_lr)
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*src_optimizer.compute_gradients(self.src_loss, non_bert_vars))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.src_train_op = src_optimizer.apply_gradients(zip(grads, vs))
        else:
            self.src_train_op = src_optimizer.minimize(self.src_loss)

        tgt_optimizer = tf.train.AdamOptimizer(learning_rate=self.tgt_lr)
        if self.cfg.grad_clip is not None and self.cfg.grad_clip > 0:
            grads, vs = zip(*tgt_optimizer.compute_gradients(self.tgt_loss, non_bert_vars))
            grads, _ = tf.clip_by_global_norm(grads, self.cfg.grad_clip)
            self.tgt_train_op = tgt_optimizer.apply_gradients(zip(grads, vs))
        else:
            self.tgt_train_op = tgt_optimizer.minimize(self.tgt_loss)

        

    def _src_predict_op(self, data):
        feed_dict = self._get_feed_dict(src_data=data, tgt_data=None, domain_labels=None)
        logits, transition, seq_len = self.sess.run([self.src_logits, self.src_transition, self.lengths],
                                                    feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def _tgt_predict_op(self, data):
        feed_dict = self._get_feed_dict(src_data=None, tgt_data=data, domain_labels=None)
        logits, transition, seq_len = self.sess.run([self.tgt_logits, self.tgt_transition, self.lengths],
                                                    feed_dict=feed_dict)
        return self.viterbi_decode(logits, transition, seq_len)

    def train(self, src_dataset, tgt_dataset):
        self.logger.info("Start training...")
        best_f1, no_imprv_epoch, src_lr, tgt_lr, cur_step = -np.inf, 0, self.cfg.lr, self.cfg.lr, 0
        total_speed = 0
        for epoch in range(1, self.cfg.epochs + 1):
            self.logger.info("Epoch {}/{}:".format(epoch, self.cfg.epochs))
            batches = self._arrange_batches(src_dataset, tgt_dataset, self.cfg.mix_rate, self.cfg.train_ratio)
            prog = Progbar(target=len(batches))
            prog.update(0, [("Global Step", int(cur_step)), ("Source Train Loss", 0.0), ("Target Train Loss", 0.0)])
            # pbar = ProgressBar(n_total=len(batches), desc='Training')
            start = time.time()
            for i, batch_name in enumerate(batches):
                cur_step += 1
                src_data = src_dataset.get_next_train_batch()
                tgt_data = tgt_dataset.get_next_train_batch()
                if batch_name == "src":                    
                    domain_labels = [[1, 0]] * src_data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=src_data, tgt_data=None, domain_labels=domain_labels,
                                                    is_train=True, src_lr=src_lr)
                    
                    _, src_cost,summary= self.sess.run([self.src_train_op,self.src_loss,self.summary_op], feed_dict=feed_dict)
                    prog.update(i + 1, [("Global Step", int(cur_step)), ("Source Train Loss", src_cost)])
                    self.train_writer.add_summary(summary, cur_step)
                    self.train_writer.flush()
                else:  # "tgt"                    
                    domain_labels = [[0, 1]] * tgt_data["batch_size"]
                    feed_dict = self._get_feed_dict(src_data=None, tgt_data=tgt_data, domain_labels=domain_labels,
                                                    is_train=True, tgt_lr=tgt_lr)
                    _, tgt_cost,summary = self.sess.run([self.tgt_train_op, self.tgt_loss,self.summary_op], feed_dict=feed_dict)
                    prog.update(i + 1, [("Global Step", int(cur_step)), ("Target Train Loss", tgt_cost)])
                    self.train_writer.add_summary(summary, cur_step)
                    self.train_writer.flush()
            if self.cfg.use_lr_decay:  # learning rate decay
                src_lr = max(self.cfg.lr / (1.0 + self.cfg.lr_decay * epoch), self.cfg.minimal_lr)
                if epoch % self.cfg.decay_step == 0:
                    tgt_lr = max(self.cfg.lr / (1.0 + self.cfg.lr_decay * epoch / self.cfg.decay_step),
                                 self.cfg.minimal_lr)
            if not self.cfg.dev_for_train:
                self.evaluate(tgt_dataset.get_data_batches("dev"), "target_dev", self._tgt_predict_op,
                              rev_word_dict=self.rev_tw_dict, rev_label_dict=self.rev_tl_dict)
            
            end = time.time()
            speed = (end-start)/len(batches)
            total_speed += speed
            total_average_speed = total_speed/epoch
            with open(os.path.join(self.cfg.checkpoint_path,'speed.txt'),"a+",encoding='utf-8') as inp:
                inp.write("The {} epoch:\n".format(epoch))
                inp.write('model time is :{} ,speed is :{}s/step\n'.format(str(end-start),str(speed)))
                inp.write('total average speed is {}s/step \n'.format(str(total_speed/epoch)))
                self.logger.info('the {} epoch speed is {}s/step,total average seed is {}s/step'.format(epoch,speed,total_average_speed))
            
            
            
            score,eval_lines,y_pred,y_true = self.evaluate(tgt_dataset.get_data_batches("test"), "target_test", self._tgt_predict_op,
                                  rev_word_dict=self.rev_tw_dict, rev_label_dict=self.rev_tl_dict)
            src_score,src_eval_lines,src_y_pred,src_y_true = self.evaluate(src_dataset.get_data_batches("test"), "src_test", self._src_predict_op,
                                  rev_word_dict=self.rev_sw_dict, rev_label_dict=self.rev_sl_dict)
            self.sess.run(tf.assign(self.tgt_f1, score["FB1"]))
            self.sess.run(tf.assign(self.src_f1, src_score["FB1"]))
            F1_summary = self.sess.run(self.F1_summary_op)
            self.train_writer.add_summary(F1_summary, epoch)
            self.train_writer.flush()
            if score["FB1"] > best_f1:
                best_f1, no_imprv_epoch = score["FB1"], 0
                self.save_session(epoch)
                save_cr_and_cm(self.rev_tl_dict, y_true, y_pred , language=self.cfg.tgt_language,cr_save_path=os.path.join(self.cfg.checkpoint_path,'cm.csv'), cm_save_path=os.path.join(self.cfg.checkpoint_path,'cm.png'))
                self.logger.info(' -- new BEST score on target test dataset: {:04.2f}'.format(best_f1))
                for line in eval_lines:
                    self.logger.info(line)
                with open(os.path.join(self.cfg.checkpoint_path,'best_dev.txt'),'w+',encoding='utf-8') as f:
                    for line in eval_lines:
                        f.write(line)
                        f.write('\n')
            else:
                no_imprv_epoch += 1
                if self.cfg.no_imprv_tolerance is not None and no_imprv_epoch >= self.cfg.no_imprv_tolerance:
                    self.logger.info('early stop at {}th epoch without improvement'.format(epoch))
                    self.logger.info('best score on target test set: {}'.format(best_f1))
                    break
           
    def evaluate_data(self, dataset, name, resource="target"):
        if resource == "target":
            self.evaluate(dataset, name, self._tgt_predict_op, self.rev_tw_dict, self.rev_tl_dict)
        else:
            self.evaluate(dataset, name, self._src_predict_op, self.rev_sw_dict, self.rev_sl_dict)
